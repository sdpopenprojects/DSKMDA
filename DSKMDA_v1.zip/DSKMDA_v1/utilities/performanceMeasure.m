function measure = performanceMeasure(test_label, predict_label, effort)
% test_label: actual label
% predict_label: predicted label 
% effort: inspection cost, usually using Lines of Code (LOC)
% 
% True Positive: the number of defective modules predicted as defective
% False Negative: the number of defective modules predicted as non-defective
% False Positive: the number of non-defective modules predictied as defective
% Ture Nagative: the number of non-defective modules predictied as non-defective

% confusion matrix
%  
%                            defective             non-defective (true class)
%  ------------------------------------------------------
%   predicted   defective        TP                  FP (Type I error)
%    class      ---------------------------------------------
%               non-defective    FN (Type II error)  TN
%  -------------------------------------------------------
% 
% 


%% non-effort-aware performance measures
predicted = predict_label;

predicted(predicted>0.5) = 1;
predicted(predicted<=0.5) = 0;

test_total = length(test_label);
posNum = sum(test_label == 1); % defective
negNum = test_total - posNum;

pos_index = test_label == 1;
pos = test_label(pos_index);
pos_predicted = predicted(pos_index);
FN = sum(pos ~= pos_predicted); % Type II error

neg_index = test_label == 0; % non-defective
neg = test_label(neg_index);
neg_predicted = predicted(neg_index);
FP = sum(neg ~= neg_predicted);  % Type I error

error = FN+FP;

TP = posNum-FN;
TN = negNum-FP;

pd_recall = 0;
pf = 0;

if TP+FN ~= 0
    pd_recall = TP/(TP+FN); % 1.0-error1/posNum;
end

if FP+TN ~= 0
    pf = FP/(FP+TN); % negNum
end

% G-mean
GM = sqrt(pd_recall.*(1-pf));

MCC = 0;
temp = sqrt((TP+FN)*(TP+FP)*(FN+TN)*(FP+TN));
if temp ~= 0
    MCC = (TP*TN-FP*FN)/temp;
end


%% effort-aware performance measures
len = length(test_label);
density = test_label./effort;

% predicted defect density, 'prediction model or regression model'
predDD = predict_label./effort;

data = [predDD',effort',test_label'];
data = sortrows(data,-1);
[pred,graph.pred] = computeArea(data,len);

% inspecting 20% effort, e.g.,using LOC
ACC = computeMeasure(data,len);

% actural defect density, 'optimal model'
data = [density',effort',test_label'];
data = sortrows(data,[-1 2]);
[opt,graph.opt] = computeArea(data,len);

%  'worst model'
data = [density',effort',test_label'];
data = sortrows(data,[1 -2]);
[wst,graph.wst] = computeArea(data,len);

if opt-wst ~= 0
    Popt = (pred-wst)/(opt-wst);
else
    Popt = 0.5;
end

% output
measure = [GM, MCC, Popt, ACC]; 



%% subfunctions
function [area,graph] = computeArea(data,len)

cumXs = cumsum(data(:,2)); % x: effort%, cumulative sums of effort
cumYs = cumsum(data(:,3)); % y: Defect%, cumulative sums of NUM

Xs = cumXs/cumXs(len);
Ys = cumYs/cumYs(len);

graph.x = Xs;
graph.y = Ys;
area = trapz(graph.x, graph.y);


%% compute recall with 20% effort
function ACC = computeMeasure(data,len)

cumXs = cumsum(data(:,2)); % x: effort%, cumulative sums of effort
cumYs = cumsum(data(:,3)); % y: Defect%, cumulative sums of NUM

Xs = cumXs/cumXs(len);
pos = find(Xs >= 0.2,1);

ACC = cumYs(pos)/cumYs(len);
