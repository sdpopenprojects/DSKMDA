function [X,Y] = getData(data)

X = data(1:end-1,:); % data features
Y = data(end,:); % label 
Y(Y>1) = 1;
