function [Xl,Yl,Xu,Yu,LOCu] = splitData(X,Y,idx,ratio)

% split training and test data
n = size(X,2);

trIdx = idx(randperm(n,ceil(ratio*n)));
% trIdx = idx(1:ceil(ratio*n));
testIdx = setdiff(idx,trIdx,'stable');

% traing data
Xl = X(:,trIdx);
Yl = Y(1,trIdx);

% test data
Xu = X(:,testIdx);
Yu = Y(1,testIdx);

LOCu = Xu(1,:);

% zscore normalization
Xl = zscore(Xl,0,2);
Xu = zscore(Xu,0,2);   
