function [score] = KMDA(Xs,Ys,Xl,Yl,Xu,Yu,opts)
% Kernel Manifold Discriminant Alignment
%

% get kernel parameters
options.t = opts.t1;
Ks = constructKernel(Xs',[],options);
Ks = Ks*diag(1./sqrt(sum(Ks.^2)));
Ks = zscore(Ks,0,2);

options.t = opts.t2;
Xt = [Xl,Xu];
Kt = constructKernel(Xt',[],options);
Kt = Kt*diag(1./sqrt(sum(Kt.^2)));
Kt = zscore(Kt,0,2);

% block data
K = blkdiag(Ks,Kt); % (ds+dt) x (ns+nt)

Y = [Ys,Yl];
Y(Y==0) = 2;
Y = [Y,zeros(1,length(Yu))];
Y = Y';

%% construct object function
% source-target discrepancy reducing term 
[~,ns] = size(Xs); % number of source instances
[dt,nt] = size(Xt);

Lr11 = eye(ns)/ns;
Lr22 = eye(nt)/nt;
Lr12 = -ones(ns,nt)/(ns*nt);
Lr21 = Lr12';
Lr = [Lr11,Lr12; Lr21,Lr22];
Lr = Lr/norm(Lr,'fro');
Fr = K*Lr*K';
Fr = max(Fr,Fr');

% locality preserving term
Ws = KNNGraph(Xs',10);
Wt = KNNGraph(Xt',10);

W  = blkdiag(Ws,Wt); % (ns+nt) x (ns+nt)
D = sum(W,2); 
L = diag(D) - W; % geometry Laplacian

% class discriminant term
Wcs = repmat(Y,1,length(Y)) == repmat(Y,1,length(Y))'; Wcs(Y == 0,:) = 0; Wcs(:,Y == 0) = 0; Wcs = double(Wcs);
Wcd = repmat(Y,1,length(Y)) ~= repmat(Y,1,length(Y))'; Wcd(Y == 0,:) = 0; Wcd(:,Y == 0) = 0; Wcd = double(Wcd);

Wcs = Wcs + eye(size(Wcs,1));
Wcd = Wcd + eye(size(Wcd,1));

Sw = sum(sum(W));

Swcs = sum(sum(Wcs));
Wcs = Wcs/Swcs*Sw;

Swcd = sum(sum(Wcd));
Wcd = Wcd/Swcd*Sw;

Dcs = sum(Wcs,2); 
Lcs = diag(Dcs) - Wcs;
Dcd = sum(Wcd,2); 
Lcd = diag(Dcd) - Wcd;

% optimizaition, parameters for tuning: set to 1 for simplicity
alpha = 1;
beta = 1;
gamma = 1;

% generalized eigenproblem
Fl = K*L*K'; 
Fl = max(Fl,Fl');
Fd = K*(Lcs-gamma*Lcd)*K'; 
Fd = max(Fd,Fd');

AA = Fr+alpha*Fl+beta*Fd; 

try
    [P,DD] = eig(AA);
catch
    lambda = 1e-6;
    I = eye(ns+nt);
    Fcs = K*Lcs*K';
    Fcd = K*Lcd*K';
    AA = Fr + alpha*Fl + beta*Fcs + lambda*I;
    BB = Fcd + lambda*I;
    [P,DD] = eig(AA,BB);
end

diagD = diag(DD);
[sD,sidx] = sort(diagD);
P = P(:,sidx);

% projected dimension
% dim = ceil(dt*0.15);
dim = 10; 

% projected data
P = P(:,1:dim);
Z = P'*K;

train_new = Z(:,1:ns);
test_new = Z(:,ns+1:end);

% normalization
train_new = zscore(train_new,0,2);
test_new = zscore(test_new,0,2);

nl = length(Yl);
tar_train_new = test_new(:,1:nl); % training target data
tar_test_new = test_new(:,nl+1:end); % test target data

% logical regresion classifier    
model = train([Ys,Yl]', sparse([train_new,tar_train_new]'),'-s 0 -c 1 -B -1 -q'); % num * fec
[predict_label, ~, prob_estimates] = predict(Yu', sparse(tar_test_new'), model, '-b 1');

if Ys(1) == 1 %
    score = prob_estimates(:,1)';
else
    score = prob_estimates(:,2)';
end
