clear all
close all
clc

addpath('.\utilities\');
addpath('.\liblinear\');

% Load data
load('.\DATA.mat')

% save path
methodName = 'DSKMDA'; 
str = '.\output\';
savePath = [str,methodName];
if exist(str,'dir') == 0
    mkdir(str)
end

% default parameters
rep = 30; % repeat 30 time
ratio = 0.1; % select 10% of target modules as training target set

proNum = size(data,1);
expRESULT = cell(proNum,1);

for i = 1:proNum  
    % target data information
    target = data{i,1};
    [Xt,Yt] = getData(target);
    IDX = data{i,3};
    
    % heterogeneous source data
    if i<=5 % --> NASA as target
        Xs = data(6:end,:);
    elseif i>5 && i<=10 % --> AEEEM as target
        Xs = data([1:5,11:end],:);
    elseif i>10 % --> ReLink as target
        Xs = data(1:10,:);
    end
        
    MEASURE = cell(rep,1);
    for loop = 1:rep
        measure = [];
        % random splitting training target data and test target data
        [Xl,Yl,Xu,Yu,LOCu] = splitData(Xt,Yt,IDX(loop,:),ratio);
        
        % using heterogeneous source to predict target 
        for j = 1:size(Xs,1)        
            % source data information
            source = Xs{j,1};
            [Xss,Ys] = getData(source);

           % get performace measures             
            mea = DSKMDA(Xss,Ys,Xl,Yl,Xu,Yu,LOCu);
            measure = [measure; mea];
        end
        MEASURE{loop,1} = measure;
    end
    expRESULT{i,1} = MEASURE;
end

% computer performance measures
median_Res = [];
all_Res = [];
for i = 1:proNum 
    currentRes = cell2mat(expRESULT{i,1});
    median_Res = [median_Res; median(currentRes,1)];
    all_Res = [all_Res; currentRes];
end

medianAll_Res = median(all_Res,1);
result = [median_Res; medianAll_Res];

save([savePath,'_EXPRESULT.mat'], 'expRESULT','result')

disp('running programe done !')
