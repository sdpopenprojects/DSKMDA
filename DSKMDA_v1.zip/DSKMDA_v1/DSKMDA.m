function [measure] = DSKMDA(Xs,Ys,Xl,Yl,Xu,Yu,LOCu)
% Data Sampling and Kernel Manifold Discriminant Alignment 
%

% SMOTE sampling 
[Xs,Ys] = SMOTE(Xs',Ys');
Xs = zscore(Xs,0,2);

% set kernel parameters
options.KernelType = 'Gaussian';
dist = pdist(Xs');
t1 = mean(dist); 

Xt = [Xl,Xu];
dist = pdist(Xt');
t2 = mean(dist);

par = [0.5 1 2];
scores = [];
for i=1:length(par)
    options.t1 = t1*par(i);
    options.t2 = t2*par(i);
    
    s = KMDA(Xs,Ys,Xl,Yl,Xu,Yu,options);
    scores = [scores; s];
end
score = mean(scores);

% evaluation
measure = performanceMeasure(Yu,score,LOCu);



